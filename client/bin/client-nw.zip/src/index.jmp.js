module.exports = function (Bungee, BungeeEngine) {
    'use strict';

    var e = { 
        children: [],
        addChild: function(child) {
            this[child.id] = child;
            for (var i in this.children) {
                if (this.children.hasOwnProperty(i)) {
                    this.children[i][child.id] = child;
                    child[this.children[i].id] = this.children[i];
                }
            }
            e.children.push(child);
            BungeeEngine.addElement(child);
            return child;
        },
        initializeBindings: function() {
            for (var i = 0; i < e.children.length; ++i) { e.children[i].initializeBindings(); }
        },
        render: function() {
            for (var i = 0; i < e.children.length; ++i) { e.children[i].render(); }
        }
    };

    Bungee.Button = function (engine, id, parent) {
        var e = new Bungee.InputItem(engine, id, parent);
        e.addProperty("label", function () {return "Yellow Tent";});
        e.addProperty("backgroundColor", function () {
        if (this.mousePressed) {
            return config.downBackgroundColor
        } else if (this.containsMouse) {
            return config.hightlightBackgroundColor
        } else {
            return config.normalBackgroundColor
        }
     });
        e.addProperty("width", function () {return this.textLabel.textWidth + (this.mousePressed ? 400 : 100);});
        e.addProperty("height", function () {return this.textLabel.textHeight + 10;});
        e.addProperty("cursor", function () {return "default";});
        e.addChild((function() {
            var e = new Bungee.Behavior(BungeeEngine);
            e.addProperty("background-color", function () {return 250;});
            e.addProperty("width", function () {return 250;});
            e.addProperty("left", function () {return 250;});
            return e;
        })());
        e.addChild((function() {
            var e = new Bungee.Text(BungeeEngine, "textLabel");
            e.addProperty("fontSize", function () {return "24px";});
            e.addProperty("text", function () {return this.parent.label;});
            e.addProperty("left", function () {return this.parent.width / 2 - this.width / 2;});
            e.addProperty("top", function () {return this.parent.height / 2 - this.height / 2;});
            e.addProperty("color", function () {return config.normalTextColor;});
            e.addChild((function() {
                var e = new Bungee.Behavior(BungeeEngine);
                e.addProperty("left", function () {return 250;});
                return e;
            })());
            return e;
        })());
        return e;
    };
    e.addChild((function() {
        var e = new Bungee.Window(BungeeEngine);
        e.addProperty("top", function () {return 0;});
        e.addProperty("left", function () {return 0;});
        e.addProperty("width", function () {return this.innerWidth;});
        e.addProperty("height", function () {return this.innerHeight;});
        e.addChild((function() {
            var e = new Bungee.Button(BungeeEngine);
            e.addProperty("left", function () {return this.parent.width/2 - this.width/2;});
            e.addProperty("top", function () {return this.parent.height/2 - this.height/2;});
            return e;
        })());
        return e;
    })());
    e.initializeBindings();
    e.render();
    return e;
};
